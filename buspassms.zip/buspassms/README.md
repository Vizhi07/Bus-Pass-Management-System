# Bus Pass Management System

Bus pass management system is a website system which has been designed specially for the admin to create instant bus pass, update, maintain and provide the various types of bus passes based upom user requirements. Once all the required information and photo received from the user, the admin can fill the pass details and generate a new bus pass. Once the bus pass has been generated, admin can print or download the bus pass and provide it to users. The system has search function also, to filter & view for any particular user info. 




### Installation
1.Download the zip file
2.Extract the file and copy buspassms folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4.Open PHPMyAdmin (http://localhost/phpmyadmin)
5.Create a database with name buspassdb
6.Import buspassdb.sql file(given inside the zip package in SQL file folder)
7.Run the script http://localhost/buspassms

### Login Details

Admin  ----->

username: admin

password: Test@123



### Main Features

- Simple Dashboard: Easy user friendly interface
- Admin panel:  Allows admins to manage the whole system
- CRUD functionalities:  Allows admin to create,read,update and delete the bus passes in a managed      format 
- Print option:  Allows admin to print or download the generated bus pass for the users  
- Fully customizable: easy to customize the bus categories, passes, pages 
- Contact: Allows users to query about the pass or other information to system admin.


## Technologies Used

1. HTML
2. CSS
3. JavaScript



# For more projects, check out our channel ☺️

https://www.youtube.com/channel/UC4_6-VSWBw_QHMyjrDDEvVQ


# 🚀Join our Instagram page for:
✅Free projects ideas
✅Complete source code download
✅Coding tips & tricks
✅Other tech updates.


# Thankyou for your support😍❤ Stay tuned and Happy learning! 🤓📚

### License
Bus Pass Management System is developed under the MIT License
