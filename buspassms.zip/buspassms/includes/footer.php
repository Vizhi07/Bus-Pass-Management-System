
	<div class="copy-right"> 
		<div class="container">
			<center><span style="color: white">&#169; <?php echo date("Y"); ?> All rights reserved. Made with &#x1F49C; by <b><a href="https://www.youtube.com/channel/UC4_6-VSWBw_QHMyjrDDEvVQ"> GPW</a></b> Team.</span></center>
		</div> 
	</div> 
	<!-- //footer -->   
	